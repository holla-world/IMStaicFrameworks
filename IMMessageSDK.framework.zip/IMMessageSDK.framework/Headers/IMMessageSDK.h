//
//  IMMessageSDK.h
//  IMMessageSDK
//
//  Created by admin on 23-12-21.
//

#import <Foundation/Foundation.h>

//! Project version number for IMMessageSDK.
FOUNDATION_EXPORT double IMMessageSDKVersionNumber;

//! Project version string for IMMessageSDK.
FOUNDATION_EXPORT const unsigned char IMMessageSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IMMessageSDK/PublicHeader.h>


